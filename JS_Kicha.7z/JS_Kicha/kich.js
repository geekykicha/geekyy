//! jaascript topic

// console.log('Hello World');

//!;;;;; VALUES AND VARIABLE///////////////////////;;///////////////////....................

// var myName = 'kicha mudhale';
// var myAge = 47;

// console.log(myAge);

//! <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<NAMING PACTICE/////////////////////////////

// var _myName = 'kicha';
// var _my__Nname = 'kicha';
// var 1myNname = 'kicha'; <<<<<<<<<<<<<<<INVALID VAR>>>>>>>>>>>>>>>>>>>>>>
// var $myNname = 'kicha';

// console.log(_myName);

//! <<<<<<<<<<<DATA= TYPES???????????????????????????

// var myName = 'kicha mudhale';
// var myAge = 47;
// var myName = true;

// console.log(myName);

// TYPE OF OPERATOR.....................................
// console.log(typeof myName);

// DATA TYPE PRACTICE>>>>>>>>>>>>>>>>>>>>>>>
// console.log(10 + '20');

// 9 - '5';

// ! console.log(9 - '5');  <<<<<<<<<<<<bug......>>>>>>>

// 'java' + 'script';
// console.log('java' + 'script');  if we need space b/w letters ' ' +' '

// ' ' + ' ';
// console.log(' ' + ' ');

// ' ' + 0;
// console.log(' ' + 0);

// 'kicha' - ' mudhale';
// console.log('kicha' - ' mudhale');  ................ nan = not a number........

// true + true;
// console.log(true + true);  ===2,,,,,in java script true=1 ,, false=0

// true + false;
// console.log(true + false); ====1

// false + true;
// console.log(false + true);    ======1

// false - true;
// console.log(false - true); ======-1

//! <<<<<<<<<<<<<<<<<<<<<INTERVIWE QUESTION//////....

//! what is diff b/w null & undefined

// var iamDon = null;
// console.log(iamDon);

// console.log(typeof iamDon);     ==null is a type of (object)==2bug

// var iamDopn;
// console.log(iamDopn);

//>>>>>>>>>>>>>>>>>>>>> INTERVIWE QUESTION 2

//! WHAT IS NaN

//? NaN = global Object

// var myPhoneno = 2453254323;

// console.log(myPhoneno);
// console.log(isNaN(myPhoneno)); false

// var myName = 'kicha mudhale';

// console.log(myName);
// console.log(isNaN(myName)); true

//! nan practice

// NaN === NaN;
// console.log(NaN === NaN); ====false

// Number.NaN === NaN;
// console.log(Number.NaN === NaN); =====false

// isNaN(NaN);
// console.log(isNaN(NaN)); =====true

// Number.isNaN(NaN);
// console.log(Number.isNaN(NaN)); ======true

//<<<<<<<<<<<<<<<<<<<< EXPRESSIONS AND OPERATORS>>>>>>>>>>>>>>>>>>>

// EXPRESSION = OPERAND + OPERATOR

// TYPES OF OPERATORS''''

// ASSIGNMENT OPERATORS (=)

// var x = 5;
// var y = 5;

// console.log('is the both x and y are equal or not' + x == y); ----bug

// ARITHMETIC OPERATORS ( + , -,  *,  /  & moduloo operator'%')

// console.log(3 + 5);
// console.log(10 - 7);
// console.log(85 * 98);
// console.log(89 / 6);

// console.log('reminder operator' + (27 % 4));

// INCREMENT AND DECREMENT OPERATORS (postfix prefix)
// operators = x++ ++x or x-- --x

// postfix = with operator after operand(x++)

//! INCERMENT

// post
// var num = 6;
// var newNum = num++ + 5;

// console.log(num); 7
// console.log(newNum); 11

// prefix = (++x)
// var num = 6;
// var newNum = ++num + 5;

// console.log(num); 7
// console.log(newNum); 12

//! DECRIMENT

// prefix = (--x)
// var num = 6;
// var newNum = --num + 5;

// console.log(num);
// 5;
// console.log(newNum);
// 10;

// postfix = (x--)

// var num = 6;
// var newNum = num-- + 5;

// console.log(num);
// 5;
// console.log(newNum);
// 11;

//! CAMPARISON OPERATOR
// this operator compares its operand & return the value (true or false)

// var a = 20;
// var b = 10;

// equal( a == b)
// console.log(a == b); false

// Not equal( a != b)
// console.log(a != b); true

// greter than ( > )
// console.log(a > b); true

// less than ( < )
// console.log(a < b); false

// greater than or equal to ( >= )
// console.log(a >= b);
// true;

// less than or equal to ( <= )
// console.log(a <= b); false

//! LOGICAL OPERATOES
// user for Boolean expression (when they are , they return a Boolean value)

// var a = 30;
// var b = -20;

// Logical and (&&)
// the output will only true when the all expressions are true
// console.log(a > b && a < b && b < 0); false

// Logical or ( || )
// the output will only true when the any one of the expresion is true
// console.log(a > b || a < b || b < 0); true

// Logical not ( ! )
// if the output is true the output will be false
// console.log(!(a > b || a < b || b < 0)); false
// console.log(!true); false

//! String CONCATENATion(operator)
// concatinate operatoe ( + ) which add two String

// console.log('kicha mudhale');

// console.log('kicha ' + 'mudhale');

// var myName = 'kicha';

// console.log(myName + ' mudhale');
// console.log(myName + ' hero');
// console.log(myName + ' villan');

// CHALLENGE NO 4>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// what is the output of 3**3?
// console.log(3 ** 3); 3*3*3

// write a program of swap of two no?
// var a = 5;
// var b = 10;

// output = b=5 a=10;
// var c = b; //c=10
// b = a; //b=5
// a = c; //a=10

// console.log('the value of a is ' + a);
// console.log('the value of b is ' + b);

// swap 2 no without another var?

// var a = 10;
// var b = 5;

// // output = b=5 a=10;

// a + b; //a=15
// a - b; //b=5
// a - b; //a=10

// console.log('the value of a is ' + a);
// console.log('the value of b is ' + b);

// INTERVIWE QUATION 4>>>>>>>>>>>>
// DIFF B/W == & === ?

// ( == ) its only check the value
// var num1 = 10;
// var num2 = '10';

// console.log(typeof num1);
// console.log(typeof num2);

// console.log(num1 == num2);
// true;

// (===) its check the value & data type
// var num1 = 10;
// var num2 = '10';

// console.log(typeof num1);
// console.log(typeof num2);

// console.log(num1 === num2);
// false;

//! CONTROL STATEMENTS/////////////////////

// if....else statements = the if statement satisfy when the given condition & if statements both are same other wise it gives else

//if raining = raincoat
// else = no raincoat

// var tomr = 'sunny';

// if (tomr == 'rain') {
//   console.log('take a raincoat');
// } else {
//   console.log('no need of raincoat');
// }

//!WRITE A PROGRAM ON LEAP YEAR(366 days)

// var year = 2020;

// if (year % 4 === 0) {
//   if (year % 100 === 0) {
//     if (year % 400 === 0) {
//       console.log('the year ' +  year + ' is  a leap year');
//     } else {
//       console.log('the year' +  year + 'is not a leap year');
//     }
//   } else {
//     console.log('the year' + year + 'is  a leap year');
//   }
// } else {
//   console.log('the year' + year + 'is not a leap year');
// }

//! WHAT IS TRUTY & FALSY VAL IN JAVASCRIPT?

// WE HAVE TOTAL 5 FALSY VALUE IN JAVASCRIPT
// i.e <<<<<<<<<<<<<<<<<0 , " " , undefined , NaN , null , false>>..
// IF WE USE FALSY CONDITIONS WE GET ONLY ELSE VALUE

// if ((score = 0)) {
//   console.log('we lost the game');
// } else {
//   console.log('we won the game');
// }

//! CONDITIONAL (TERNARY) OPERATOR
// the operator which is having 3 operands
// i.e variable name = (condition) ? value 1 : value 2;

// var age = 20;

// console.log(age >= 20 ? 'u can marry' : 'u cant marry')

//! SWITCH STATEMENT
// evaluvate the expression , match the expression with the case, & execute the associate of that case
// break = which terminate the case

// var area = 'triangle';
// var PI = 3.142,
//   l = 5,
//   b = 9,
//   r = 7;

// switch (area) {
//   case 'circle':
//     console.log('the area of the circle is : ' + PI * r ** 2);
//     break;

//   case 'triangle':
//     console.log('the area of the triangle is : ' + (l * b) / 2);
//     break;

//   case 'rectangle':
//     console.log('the area of the recangle is : ' + l * b);
//     break;

//   default:
//     console.log('please enter valid data');
// }

//! WHILE LOOP STATEMENT>>>>><<<<<<<
// the while statement create a loop upto the given condition evaluate true

// { }=block scope

// var num = 0;
// while (num <= 10) {
//   console.log(num); //infinte loop
//   num++;
// }

//! DO-WHILE LOOP{{{{{{{{{{{{{}}}}}}}}}}}}}
// in this the output will comes first than it check the condition

// var num = 0;
// do {
//   console.log(num);
//   num++;
// } while (num <= 10);

//! FOR LOOP STATEMENT ((((((((()))))))))

// for(intializer;condition ; iteration)

// for (var num = 0; num <= 10; num++) {
//   console.log(num);
// }

//! CHALLENGE NO 6><><><TABLE OF ANY NO ><><><>

// Javascript program to write table of (6)?

// for (var num = 1; num <= 10; num++) {
//   var tableOf = 6;
//   console.log(tableOf + ' * ' + num + ' = ' + tableOf * num);
// }

//! FUNCTIONS IN JAVASCRIPT {{{{{{{{}}}}}}}}

// javascript function block of code to perform to perticuler task

// FUNCTION DEFINATION

// BEFORE WE USE A FUNCTION , WE NEED TO DEFIND IT

// DEFIND BY

// the parameters of the functions r enclosed in parentheses & seperated by commas
// { //statement}

// DEFINING THE Function

// function sum() {
//   var a = 10,
//     b = 20;
//   var total = a + b;
//   console.log(total);
// }

// CALLING THE Function
// Defining the function will not excuted

// sum();

//! DIFF B/W Function ARGUMENT & Function PARAMETER

// F P = LISTED IN Function DEFINATION
// F A = PASSED IN  Function CALL

// function sum(a, b) {
//   //parameter
//   var total = a + b;
//   console.log(total);
// }

// sum(30, 5); //Argument
// sum(50, 70);

//! INTERVIWE QUESTION
// WHY FUNCTION
// U CAN REUSE CODE ; DEFINE THE CODE ONCE & REUSE MANY TIMES WITH DIFFERENT ARGUMENTS

//! FUNCTIN EXPRESSION
// CREATE THE Function & PUT INTO THE VARIABLE

// function sum(a, b) {
//   var total = a + b;
//   console.log(total);
// }

//  var funExp = sum(30, 5);

// return keyword>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//WHEN WE US RETURN=   THE Function ST0P EXECUTING

// function sum(a, b) {
//   return (total = a + b);
// }

// var funExp = sum(30, 15);
// console.log('the sum of two nos' + funExp);

//! Anonymus function
// function without name is a anonymus function

// var funExp = function (a, b) {
//   return (total = a + b);
// };

// var sum = funExp(20, 67);
// var sum1 = funExp(36, 81);

// console.log(sum > sum1);

//! <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   MODREN JAVASCRIPT >>>>>>
// Feature of ECMAscript 2015 or ES6

// LET VS CONST VS VAR
// VAR == function scope
// LET & CONST == BLOGE SCOPE

// var & let function works same
// const vaiable name won;t change

// var myName = 'kicha';
// console.log(myName);

// myName = 'mudhale';
// console.log(myName);

// function Biodata() {
//   let myFirstname = 'kicha';
//   console.log(myFirstname);

//   if (true) {
//     let myLastname = 'mudhale';
//     console.log(myLastname);

//     console.log('inner' + myLastname);
//     console.log('inner' + myFirstname);
//   }
// //   console.log('innerOuter' + myLastname); //let & const wont show this line bcz its a bloge scope
// }
// //const will also not execute after the global scope
// Biodata();//var will excecute the whole program

//!<<<<<<< TEMPLATE LITERALS{{{{{{{{{{{$$$$$$$$`````````{{{{{{{{{}}}}}}}}}}}}}}}}}}}}

// for (let num = 1; num <= 20; num++) {
//   let tableOf = 8;
//   //   console.log(tableOf + ' * ' + num + ' = ' + tableOf * num);
//   console.log(`${tableOf} * ${num} = ${tableOf * num}`);
// }

// DEFULT PARAMETER

// it used to when the function call r not defind

// function mult(a, b = 7)//we can assigne parmeter value b=7 as defult
//  {
//   return a * b;
// }
// console.log(mult(5));

//! FAT ARROW Function
// NORMAL WAY OF Function PROGRAM
// console.log(sum());

// function sum() {
//   let a = 4,
//     b = 5;
//   let sum = a + b;
//   return `the of two no is ${sum}`;
// }

// HOW TO CONVERT IN INTO FAT ARROW

// const sum = () => {
//   let a = 4;
//   let b = 56;
//   let sum = a + b;
//   return `the of two no is ${sum}`;
// };
// console.log(sum());

//! OR

// FOR SINGLE LINE CODE NO NEED TO WRITR return
// const sum = () => `the of two no is ${(a = 2 + (b = 4))}`;

// console.log(sum());

//! Array IN JAVASCRIPT<><>>><<><><><><><><<>
// storing multiple data type in single var

// var myFriends = ['krishna', 'kicha', 'mudhale', 'hero'];
// console.log(myFriends);

// TRAVERSAL OF ARRAYS[0,1,2,3]

// var myFriends = [
//   'krishna',
//   'kicha',
//   'mudhale',
//   'hero',
//   'krishna',
//   'kicha',
//   'mudhale',
// ];
// console.log(myFriends[1]);

// // LENGTH OF AN Array
// console.log(myFriends.length);

// // TO GET THE LAST ELEMENT OF AN ARRAY
// console.log(myFriends[myFriends.length - 1]);

//! for in
// shoes the index value of an array

// var myFriends = ['krishna', 'kicha', 'mudhale', 'hero'];

// for (let elements in myFriends) {
//   console.log(elements);
// }

//! for off
// shoes the data value of an array

// var myFriends = ['krishna', 'kicha', 'mudhale', 'hero'];

// for (let elements of myFriends) {
//   console.log(elements);
// }

//! forEach == COMBINATION OF FOR IN & FOR OF
// WE CANT USE breakIN FOREACH LOOP

// var myFriends = ['krishna', 'kicha', 'mudhale', 'hero'];

// myFriends.forEach(function (element, index, array) {
//   console.log(element + ' index :' + index + ' ' + array);
// });

// we cant use this statement in fat arrow
// myFriends.forEach((element, index, array) => {
//   console.log(element + ' index :' + index + ' ' + array);
// });

//! SEARCHING & FILTERING OF AN Array
// Array.prototype,indexOf()
// indexOf = return the 1st index of an Element within an Array equal
// too Element, -1 if none is found it start searching from 0 indexOf

// var myFriends = ['krishna', 'kicha', 'mudhale', 'hero', 'King'];
// console.log(myFriends.indexOf('kicha', 2));

// Array.prototype,indexOf()

// var myFriends = ['krishna', 'kicha', 'mudhale', 'hero', 'King'];
// console.log(myFriends.lastIndexOf('kicha', 4));

//! HOW TO INSERT , ADD ,delete & REPLACE ELEMENTS IN ARRAY
//! Array.prototype.push()

// the push methode add one or more elelment at the end of an Array
// & return the new length of an Array

// const animals = ['krishna', 'kicha', 'mudhale', 'hero', 'King'];
// const count = animals.push('don');
// console.log(animals);
// console.log(count);

//! Array.prototype.unshift()
// it insert the element at the end of an Array

// const animals = ['krishna', 'kicha', 'mudhale', 'hero', 'King'];
// const count = animals.unshift('don');
// console.log(animals);
// console.log(count);

//! Array.prototype.pop()
// it remove an last element in the Array & it will change the lengthof Array

// const animals = ['krishna', 'kicha', 'mudhale', 'hero', 'King'];
// // const count = animals.pop();
// console.log(animals.pop());
// console.log(animals);
// console.log(count);

//! Array.prototype.shift()
// it remove the first Element from an Array
// const animals = ['krishna', 'kicha', 'mudhale', 'hero', 'King'];
// // const count = animals.pop();
// console.log(animals.shift());
// console.log(animals);

// CHALLENGE TIME{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}
// 1) add dec at the last of the Array
// 2) what is the return value of the splice method
// 3) update march to March (update)
// 4) delete april from Array

//! Array.prototype.splice()
// splice(start: number, deleteCount?: number): string[]

// ADDS AND/OR REMOVES FROM THE Array
// const months = ['jan', 'feb', 'mar', 'april', 'july'];

//sol 1
// const newMonths = months.splice(5, 0, 'dec');
// const newMonths = months.splice(months.length, 0, 'dec');

// console.log(months);

// what is the return value of the splice method
// the splice methode returns mainly used for delete Element
// sol 2
// console.log(newMonths);

// 3) update march to March (update)
// const months = ['jan', 'feb', 'mar', 'April', 'july'];

// // sol 3
// const indexofMonth = months.indexOf('April'); //searching  the index val of array
// if (indexofMonth != -1) {
//   //   const updateMonth = months.splice(2, 1); //sol 4
//   const updateMonth = months.splice(1, Infinity); //Infinity used when we have to del all the Elementafter the selected one

//   console.log(months);
//   console.log(updateMonth); //shows del element
// } else {
//   console.log('no such data found');
// }

//! MAP , REDUCE & FilTER IN Array
// Array.prototype.map()
// IT return THE Element OF Array CONTAING THE RESUTL OF CALLING A Function OF Array Element
// WE CAN ADD MULTIPLE METHODS LIKE .REDUCE() ,.SORT(),.FILTER = chainable methode

// const array1 = [1, 4, 8, 46, 73];
// //num > 8

// let newArr = array1.map((curElmy, index, arr) => {
//   return curElmy > 8;
// });
// console.log(array1);
// console.log(newArr);

// let newArr = array1.map((curElmy, index, arr) => {
//   return `index no = ${index} and the val is ${curElmy} belongs to ${arr}`;
// });
// IT return A NEW Array WITHOUT CHANGING ORIGINAL Array
// console.log(newArr);

// CHALLENGE TIME{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}
//1) SQUARE ROOT THESE ELEMENT?
// 2) MULTIPLE EACH ELEMENT BY 2 & return ONLY THOSE ELEMENT WHICH R > THAN 10?

// sol 1
// let arr = [25, 36, 49, 64, 81];

// let arrSqur = arr.map((curElmt) => Math.sqrt(curElmt));

// console.log(arrSqur);

// // sol 2
// let arr = [2, 3, 4, 6, 8];

// let arr2 = arr
//   .map((curElem) => curElem * 2)
//   .filter((curElem) => curElem > 10)
//   .reduce((accumulator, curElem, index, arr) => {
//     return (accumulator += curElem);
//   });
// console.log(arr2);

//! REDUCE METHODE
// it cnverts 2d or 3d into singke dimension
// it reduce the methide of excecuting & return a single value

// the reduce function ARGUMENTS

// accumalator
// current value
// current index
// source Array

// let arr = [2, 3, 5];

// let sum = arr.reduce((accumulator, curElem, index, arr) => {
//   return (accumulator *= curElem);
// }, 7); //adding initial val as 7

// console.log(sum);

// how to cnverts 2d or 3d into singke dimension

// const arr = [
//   ['zone_1', 'zone_2'],
//   ['zone_3', 'zone_4'],
//   ['zone_6', 'zone_6'],
//   ['zone_7', 'zone_8'],
// ];

// let flateArr = arr.reduce((accumul, curelem) => {
//   return accumul.concat(curelem);
// });
// console.log(flateArr);

//! STRINGS IN JAVA SCRIPTP{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}
// ANY DATA WRITTEN INSIDE THE QUOTES
// STORING THE DATA INSIDE THE SINGLE QUOTES OR DOUBLE

// let myName = 'krishna mudhale';

// let myNickname = 'kicha';

// console.log(myName);
// console.log(myNickname);
// console.log(myName.concat(myNickname));
// console.log(myName.length);

// escape CHARECTER\\\\\\\\\\\\\\\//////////////////////////////
// // we use /////////////////////////////////
// let mySentance = 'kicha mudhale hero "krishna" don';
// console.log(mySentance);

// String.prototype.indexOf
// ///////////////////
// let mySentance = 'kicha mudhale hero "krishna" don';
// console.log(mySentance.indexOf('h', 19));

// String.prototype.lastIndexOf

// let mySentance = 'kicha mudhale hero "krishna" don';
// console.log(mySentance.lastIndexOf('h', 5));

//! SEARCHING IN StringS{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}
// THE SEARCH METHODE SPECIFY A PERTICULAR STRING
// & return the position of the match & case sensitive
// const myData = 'i am krishna  mudhale';
// let sData = myData.search('krishna');

// console.log(sData);

//! EXTRACTING String PARTS<><><>>>>>>>><><<><>
// 3 METHODES R THERE

// slice(start,end)
// substring(start,end)
// substr(start,length)

//! the slice() methode
// extracte a part of a String & return the extracte part in new String
// the methode have 2 parameters : start & end position
// it does not display end argument
// var str = 'orange , greps , kiwi';
// let res = str.slice(0, 6);

// console.log(res);

//! THE SUBSTRING() METHODE
// the substring does not allpw negetove index
// var str = 'orange , greps , kiwi';
// let res = str.substring(0, 6);

// console.log(res);

//! THE substr(start,length) METHODE
// the substr does allpw negetove index

// var str = 'orange , greps , kiwi';
// let res = str.substr(0, 6);

// let res = str.substr(-6);

// console.log(res);

//! REPLACING IN STRING METHODE
// String.prototype.replace(searching fpr , replacing with) & its case sensitive

// const myData = 'i am krishna  mudhale';
// let sData = myData.replace('krishna', 'KRISHNA');

// console.log(sData);

//! EXTRACTING STRING CHARECTERS>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// 3 METHODES

// ChareAt (position)
// ChareCodeAt (position)
// property access [ ]

// THE  ChareCodeAt (position) METHODE
// return the charexter at a specified index(position) in a String

// let str = 'Hellow world';
// console.log(str.charAt(5));

// the  ChareCodeAt (position) methode
// return the unicode of a charecter
// the methode return UTF-16 code (an integer b/w o - 65535)
// unicode is a standerd provides a unique Number for every charecter

// let str = 'Hellow world';
// console.log(str.charCodeAt(5));

// CHALLENGE TIME[[[[[[[[[[[[[[[[[[[[[]]]]]]]]]]]]]]]]]]]]]
// WRITE UNICODE OF A LAST CHARECTER

// let str = 'Hellow world';
// let lastChar = str.length - 1;
// console.log(str.charCodeAt(lastChar));

//! THE  property access [ ] METHODE

// let str = 'Hellow world';
// console.log(str[2]);

//! OTHER USEFUL METHODES OF STRINGS
// let myName = 'kicha';
// console.log(myName.toUpperCase());
// console.log(myName.toLowerCase());

// let fName = 'kicha';
// let lName = 'mudhale';

// console.log(fName.concat(lName));
// console.log(fName.concat(' ', lName));

//! String.trim() methode
// it removes the white space from the both side of the String

// var str = '            Hello World                          ';
// console.log(str.trim());

//! CONVERTING STRING INTO AN ARRAY
// with split methode()

// var txt = 'a, b,c | d, e,f';
// console.log(txt.split(',')); //split on commas
// console.log(txt.split(' ')); //split on space
// console.log(txt.split('|')); //split on pipe

//! DATE & TIME IN JAVA SCRIPT.///..,;;;;;;;;,;,;,;,

// CREATING DATE OBJECT in 4 ways

//! 1) new Date()
// date object created by new date() constructor

// let currDate = new Date();
// console.log(currDate);
// console.log(currDate.toLocaleString());//7/22/2021, 11:44:02 PM
// console.log(currDate.toString());//Thu Jul 22 2021 23:44:02 GMT+0530 (India Standard Time)

//!2) DATE.NOW()
// RETURNS THE NUMERIC VALUE TO THE CURRENT TIME
//  = THE NO OF MILLISECONDS ELAPSED SINCE JAN 1 1970 00;00;00 UTC

// console.log(Date.now()); //1626978210837;

//! 3) new date (year,mon,day,hours,min,sec,millisec)
// IN JAVA SCRIPT MONTHS COUNTS FROM 0 TO 11

// var d = new Date(2021, 6, 24, 12, 13, 45, 22);  //THE MONTH SHOULD BE SPECIFIED
// console.log(d.toLocaleString());

//! 4) new date (datestring)
// CREATE A NEW DATA OBJECT FROM DATESTRING

// var d = new Date('july 24 , 2021 11:32:42');
// console.log(d.toLocaleString());

//!5) new date (milliseconds)
// CREATE A NEW DATA OBJECT AS ZERO TIME PLUS MILLISECONDS

// var d = new Date(0);      //1/1/1970, 5:30:00 AM
// var d = new Date(1626978210837);   //7/22/2021, 11:53:30 PM
// console.log(d.toLocaleString());

//! DATE METHODES

// const currDate = new Date();

// HOW TO GET INDIVIUAL DATES
// console.log(currDate.toLocaleString());
// console.log(currDate.getFullYear());
// console.log(currDate.getMonth());
// console.log(currDate.getDate());
// console.log(currDate.getDay());

// HOW TO SET INDIVIUAL DATES
// console.log(currDate.setFullYear(2021));
// console.log(currDate.setMonth(10));
// console.log(currDate.setDate(5));
// console.log(currDate.toLocaleString());

//! time METHODES

// const currTime = new Date();

// HOW TO GET INDIVIUAL time
// console.log(currTime.getTime());     //1627068766119
// console.log(currTime.getHours());
// console.log(currTime.getMinutes());
// console.log(currTime.getSeconds());
// console.log(currTime.getMilliseconds());

// HOW TO SET INDIVIUAL time
// console.log(currTime.setTime()); //1627068766119
// console.log(currTime.setHours(5));
// console.log(currTime.setMinutes(5));
// console.log(currTime.setSeconds(5));
// console.log(currTime.setMilliseconds(5));

//! MATH opertions
// MATH OPERTION DEAL WITH NUMBERS

// console.log(Math.PI);

//! MATH ROUND() METHODE
// return the value of x rounded to nearedt integer

// let num = 10.477;   //10
// let num = 10.577;       //11

// console.log(Math.round(num));

//! Math pow() methode
// return the power value

// console.log(Math.pow(2, 3));
// console.log(2 ** 3);

//! MATH SQRT METHODE
// return the square root of any number

// console.log(Math.sqrt(35));
// console.log(Math.sqrt(45));
// console.log(Math.sqrt(85));

//! Math abs () METHODE
// return the  absolute (positive) value

// console.log(Math.abs(-55));
// console.log(Math.abs(-76.5));
// console.log(Math.abs(-52));
// console.log(Math.abs(4 - 7));

//! MATH CIEL () METHODE
// return the value rounded up nearest integer

// console.log(Math.ceil(6.5));
// console.log(Math.round(6.5));
// console.log(Math.ceil(99.1));
// console.log(Math.round(99));

//! MATH FLOOR () METHODE
// return the value rounded down nearest integer

// console.log(Math.floor(99.1));
// console.log(Math.floor(99.5));

//! Math min () methode
// return the lowest value

// console.log(Math.min(10, 24, 2, +5, -252, -5795, +52));

//! Math max () methode
// return the highest value

// console.log(Math.max(10, 24, 2, +5, -252, -5795, +52));

//! Math random () methode
// return the any random number 0-1

// console.log(Math.floor(Math.random() * 10));

//! Math.trunc ( methode)
// return the intefer part of the number

// console.log(Math.trunc(4.5));
// console.log(Math.trunc(-99.5));

//! Document Object model in JavaScript

// 1️ Window is the main container or we can say the
// global Object and any operations related to entire
// browser window can be a part of window object.

// For ex  the history or to find the url etc.

//  whereas the DOM is the child of Window Object

// All the members like objects, methods or properties.

// If they are the part of window object then we do not refer
// the window object. Since window is the global object
// so you do not have to write down window.
// - it will be figured out by the runtime.

// For example
//  window.screen or just screen is a small information
// object about physical screen dimensions.
//  window.location giving the current URL
//  window.document or just document is the main object
// of the potentially visible (or better yet: rendered)
// document object model/DOM.

//! Where in the DOM we need to refer the document,
// if we want to use the document object, methods or properties
// For example
//  document.getElementById()

// !Window has methods, properties and object.
// ex setTimeout() or setInterval() are the methods
// where as Document is the object of the Window and
// It also has a screen object with properties
// describing the physical display.

// Now, I know you have a doubt like we have seen the methods
// and object of the global object that is window. But What about
// the properties of the Window Object

// so example of window object properties are
// innerHeight,
// innerWidth and there are many more

// let's see some practical in DOM HTML file

// ************** DOM vs BOM *******************

//!  The DOM is the Document Object Model, which deals with the document,
// the HTML elements themselves, e.g. document and all traversal you
// would do in it, events, etc.

// For Ex:
// change the background color to red
// document.body.style.background = "red";

//  The BOM is the Browser Object Model, which deals with browser components
// aside from the document, like history, location, navigator and screen
// (as well as some others that vary by browser). OR
// In simple meaning all the Window operations which comes under BOM are performed
// usign BOM

// Let's see more practical on History object

// Functions alert/confirm/prompt are also a part of BOM:
// they are directly not related to the document,
// but represent pure browser methods of communicating with the user.

// alert(location.href); // shows current URL
// if (confirm("Want to Visit ThapaTechnical?")) {
//   location.href = "https://www.youtube.com/thapatechnical"; // redirect the browser to another URL
// }

//! Navigate through the DOM

// 1: document.documentElement
// returns the Element that is the root element of the document.
// 2: document.head
// 3: document.body
// 4: document.body.childNodes (include tab,enter and whiteSpace)
// list of the direct children only
// 5: document.children (without text nodes, only regular Elements)
// 6: document.childNodes.length

//  Practice Time
// How to check whether an element has child nodes or not?
// we will use hasChildNodes()

//  Practice Time
// How to find the child in DOM tree
// firstChild vs firstElementChild
// lastChild vs lastElementChild
// const data = document.body.firstElementChild;
// undefined
// data
// data.firstElementChild
// data.firstElementChild.firstElementChild
// data.firstElementChild.firstElementChild.style.color = "red"
// vs
// document.querySelector(".child-two").style.color = "yellow";

// ! How to find the Parent Nodes
// document.body.parentNode
// document.body.parentElement

//!  How to find or access the siblings
// document.body.nextSibling
// document.body.nextElementSibling
// document.body.previousSibling
// document.body.previousElementSibling

//! HOW TO SEARCH THE ELEMENT & THE REFERANCES IN NEW FILE

// -------------------------------------------------------------------------------------------

//! EVENTS IN JAVASCRIPT

// HTML events are "things" that happen to HTML elements.
// When JavaScript is used in HTML pages, JavaScript can "react" on these events.

//! HTML Events
// An HTML event can be something the browser does, or something a user does.

// Here are some examples of HTML events:

// An HTML web page has finished loading
// An HTML input field was changed
// An HTML button was clicked
// Often, when events happen, you may want to do something.

// JavaScript lets you execute code when events are detected.

// HTML allows event handler attributes, with JavaScript code,
// to be added to HTML elements.

//!  4 ways of writing Events in JavaScript

// 1: using inline events alert();
// 2: By Calling a funcion (We already seen and most common way of writing)
// 3: using Inline events (HTML onclick="" property and element.onclick)
// 4: using Event Listeners (addEventListener and IE's attachEvent)

// check the Events HTML File

//!  What is Event Object?
// Event object is the parent object of the event object.
// for Example
// MouseEvent, focusEvent, KeyboardEvent etc

//! MouseEvent in JavaScript
// The MouseEvent Object
// Events that occur when the mouse interacts with the HTML
// document belongs to the MouseEvent Object.

//! KeyboardEvent  in JavaScript
// Events that occur when user presses a key on the keyboard,
// belongs to the KeyboardEvent Object.

//! InputEvents in JavaScript
// The onchange event occurs when the value of an element has been changed.

// For radiobuttons and checkboxes, the onchange event occurs when the
// checked state has been changed.

//![[[[[[[[[[[[]]]]]]]]]]]] CONTINUE  IN NEW FOLDER[[[[[[[[[[[[[[[[[[[]]]]]]]]]]]]]]]]]]]

//! The window object allows execution of code at specified time intervals.

// These time intervals are called timing events.

// The two key methods to use with JavaScript are:

// setTimeout(function, milliseconds)
// Executes a function, after waiting a specified number of milliseconds.

// setInterval(function, milliseconds)
// Same as setTimeout(), but repeats the execution of the function continuously.

//![[[[[[[[]]]]]]]] OOPS IN JAVASCRIPT[[[[[[[[[]]]]]]]]]

//! What is Object Literal?

// Object literal is simply a key:value pair data structure.

// Storing variables and functions together in one container,
// we can refer this as an Objects.

// object = school bag

// How to create an Object?

//! 1st way

// let bioData = {
//   myName: 'kicha mudhale',
//   myAge: 19,
//   getDate: function () {
//     console.log(`MyName Is ${bioData.myName} & my age is ${bioData.myAge}`);
//   },
// };
// bioData.getDate();

//! 2nd way NO NEES TO WRITE FUNCTION AS WELL AFTER ES6

// let bioData = {
//   myName: 'kicha mudhale',
//   myAge: 19,
//   getDate() {
//     console.log(`MyName Is ${bioData.myName} & my age is ${bioData.myAge}`);
//   },
// };
// bioData.getDate();

//! WHAT IF WE WANT OBJECT AS A VALUE INSIDE ANA OBJECT

// let bioData = {
//   myName: {
//     realName: 'kicha',
//     surName: 'mudhale',
//   },
//   myAge: 19,
//   getDate() {
//     console.log(`MyName Is ${bioData.myName} & my age is ${bioData.myAge}`);
//   },
// };
// console.log(bioData.myName.surName);

//! WHAT IS THIS OBJECT

// The definition  of "this" object is that it contain the current context.

// The this object can have different values depending on where it is placed.

//! For Example 1
// console.log(this.alert('Awesome'));
// it refers to the current context and that is window global object

//! ex 2
// function myName() {
//   console.log(this);
// }
// myName();

//! ex 3

// var myNames = 'vinod';
// function myName() {
//     console.log(this.myNames);
// }
// myName();

//! ex 4
// const obj = {
//     myAge : 26,
//     myName() {
//       console.log(this.myAge);
//     }
// }
// obj.myName();

//! EX 5
// THIS OPERATION DOES NOT WORKS IN => FAT ARROW Function
// const obj = {
//   myAge: 19,
//   myName: () => {
//     console.log(this);
//   },
// };
// obj.myName();

//! [[[[[[[[[[[[[INTERVIWE QUESTION
// let bioData = {
//   myName: {
//     realName: 'kicha',
//     surName: 'mudhale',
//   },
//THINGS TO REMEMBER IS THAT THE MYNAME IS THE KEY & THE OBJECT IS ACT LIKE VALUE
//   myAge: 19,
//   getData() {
//     console.log(
//       `my name is ${this.myName.surName} and my age is ${this.myAge}`
//     );
//   },
// };
// bioData.getData();

//! [[[[[[[[[[[[[[[[[[[[[]]]]]]]]]]]]]]]]]]]]]  ECMASCRIPT{{{{{{{{{{{{{{}}}}}}}}}}}}}}
//!             DESTRUCTURE IN JAVASCRIPT

//  the Destructuring assignment syntex is javascript expression
//  that makes it possible to unpack the values from arrays
//  or properties from Objects, into distinct variable

//!  ARRAY DeStRUCTURING
// const myBioData = ['kicha', 'mudhale', 19];

// let myFName = myBiodata[0]
// let myLName = myBiodata[1]
// let myAge = myBiodata[2]

// let [myFName, myLName, myAge] = myBioData;
// console.log(myAge);

// we can add value too
// let [myFName, myLName, myAge, myDegree = 'engineering'] = myBioData;
// console.log(myDegree);

//! Object DeStRUCTURING

// const myBiodata = {
//   myFName: 'kicha',
//   myLName: 'mudhale',
//   myAge: 19,
// };

//     let age = myBiodata.myAge
//     let myFName = myBiodata.myFName

//! we can write with the help of object distructuring [] = {}

// let { myFName, myLName, myAge, myDegree = 'engineering' } = myBiodata;
// console.log(myDegree);

//!   OBJECT Properties[[[[[[[[[[[[[[[[[[[]]]]]]]]]]]]]]]]]]]

// we can use now dynamic Data(properties)

// let myName = 'kicha';
// const myBio = {
//         myName : "Hello how are you ?"
//         19 : "is my age"
// }

// console.log(myBio);

// we can add dynamic data by using [] in key; and also perform mathamatical operation too - (dynamic data one below)

// let myName = 'kicha';
// const myBio = {
//         [myName] : "Hello how are you ?",
//         [10 + 9] : "is my age"
// }

// console.log(myBio);

// if the both key and value are same than no need to enter key and value
// NO need to write key and value. if both are same

// let myName = 'kicha';
// let myAge = 19;
// const myBio = {
//         myName : myName,
//         myAge : myAge
// }

// console.log(myBio);

// so both are same than we can write below

// let myName = 'kicha';
// let myAge = 19;

// const myBio = { myName, myAge }

// console.log(myBio);

//! FAT ARROW Function[[[[[[[[[[[]]]]]]]]]]]

// NORMAL WAY OF WRITING Function

// console.log(sum());

// function sum() {
//   let a = 5;
//   b = 6;
//   let sum = a + b;
//   return `the sum of 2 numbers is ${sum} `;
// }

//! HOW TO CONVERT IN INTO FAT ARROW Function

// const sum = () => `the sum of 2 numbers is ${(a = 5) + (b = 6)}`;

// console.log(sum());

//! [[[[[[[SPREAD OPERATORS...colors

// const colors = ['red', 'blue', 'green', 'black'];

// const myColors = ['red', 'blue', 'green', 'black', 'yellow', 'white'];
// 2md time add one more color om top & tell we need to write it again
// pn mycolor array too

// const MyFavcolors = ['yellow', 'black', ...colors];

// console.log(MyFavcolors);

//! ]]]]]]]]]]]] ES7 FEATURES]]2016]]]]]]]]]]]]]]]]]]]]]

//! 1) Array include
// const colors = ['red', 'blue', 'green', 'black'];
// const isPresent = colors.includes('red'); //true

// console.log(isPresent);

//! 2) ** = EXPONTIAL OPERATORS
// console.log(2 ** 6);

//! ]]]]]]]]]]]] ES8 FEATURES]]2017]]]]]]]]]]]]]]]]]]]]]
// String padding
// Object.values()
// Object.entries()

// const message = 'my name is kicha mudhale';

// console.log(message);
// console.log(message.padStart(8));
// console.log(message.padEnd(8));

//! Object.values()
// const person = { name: 'kicha', age: 19 };

// console.log(Object.values(person));

// Object.entries()
// const person = { name: 'kicha', age: 19 };

// console.log(Object.entries(person));

//! ]]]]]]]]]]]] ES9 FEATURES]]2018]]]]]]]]]]]]]]]]]]]]]
// const person = { name: 'kicha', age: 19 };

// const sperson = { ...person };

// console.log(sperson);
// console.log(person);

//! ]]]]]]]]]]]] ES10 FEATURES]]2019]]]]]]]]]]]]]]]]]]]]]

// Array.prototype.(flat, flatMap)
// Object.fromEntries()
// String.prototype.{trimStart, trimEnd}
// Symbol, prototype, discription
// well found JSON.stringify()
// function.prototype.toString()
// JSON improvements

//! Array.prototype.(flat, flatMap)

// flatten an Array means to convert  the 3d or 2d Array into a single dimesional array

// const arr = [
//         ["zone_1","zone_2"],
//         ["zone_3","zone_4"],
//         ["zone_5","zone_6"],
//         ["zone_7",["zone_7","zone_8"],],
//         ];

// Old method

// let flatArr = arr.reduce((acc, currEle) => {
//         return acc.concat(currEle);
// })
// console.log(flatArr);

//! by using Flat ES8

// console.log(arr.flat());

// to make it further ( 2 dimesional level to more simply increse the number of "Infinity")

// console.log(arr.flat(2));

//! Object.fromEntries()

// we use object.entries() to convert object to array and
// and Object.fromEntries() to convert array to object

// const person = { name: 'krishna', age: 19};

// console.log(Object.entries(person));

// const arrObj = Object.entries(person);

// console.log(Object.fromEntries(arrObj));

//! ]]]]]]]]]]]] ES11 FEATURES]]2020]]]]]]]]]]]]]]]]]]]]]

//! BIGINT

// let oldNum = Number.MAX_SAFE_INTEGER;
// console.log(oldNum);

// just by adding n after any number it will consider bigint ( to the max numbers)
// console.log(9007199254740991n + 15n);

// let newNum = 9007199254740991n + 15n;
// console.log(newNum);
// console.log(typeof newNum);

//! NULLISH = comapring the left & right part of the variables

// const too = null ?? "default string";
// console.log(too);

// it is a new logical operator
// it will compare the rignt and left side and returen the "other then NULL values"

//! 2014("use strict")

// "use strict";
// x = 3.14;
// console.log(x);

// let X= 3.14;
// console.log(X);

//! ***************************** ADVANCED JAVASCRIPT   &&&&&&&&&&&&&&&&&&&&&&

// EVENT PROPAGATION(EVENT BUBBLING AND EVENT CAPTURUNG)
// HIGHER ORDER Function
// CALLBACK FUNCTION
// FUNCTION CARRYNG(ASYNCHORNUS IN JAVASCRIPT)
// CALLBACK HELL
// AJAX CALL USING XMLHttpRequest
// BONUS SECTION JSON
// fetch API
// PROMISES
// ASYNC-await
// Error HANDLING IN js

//! 1) EVENT PROPAGATION(EVENT BUBBLING AND EVENT CAPTURUNG)

// Event bubling and capturing are two ways of event propogation in the HTML DOM API,
// when an event occurs in an Element inside another Element and both Elements have registered
// a handle for that event

// the event propogation mode determines in which order the Element recive the Element

// propogation broadly catagarized into 3 main types

// the capture Phase - Going from window to the Event target Phase
// the target phase - it is the target phase
// the bubble phase - from the Event target parent back to the window

//! Event bubbling

// with event bubling the event is first captured and handled by the innermost Element than propogated
// to the outer Elements

//! event capturing

// with Event capturing the event is captured by the outermost element and propogated to the inner element
// capturing is also called tricking which helps remember the propogation order

//! [[[[[[[[[[[[[[[[]]]]]]]]]]]]]]]] watch the example in files(bubbling)

//! 2) HIGHER ORDER Function
// function which takes another function as an argument is called HOF
// wo function jo dusra function ko as an arguement accept krta hai use HOF kehte hai

//! 3) CALLBACK FUNCTION

// a callback function is a fuction that is passed as an arguement to another fuction to be 'called back'
// at a later time

// jis bhi fuction ko hum kisi aur fuction ke under as an arguement pass karte hai than usko
// hum callback fuction bolte hai

//? create an calculator

// const add = (a, b) => {
//   return a + b;
// };

// const sub = (a, b) => {
//   return Math.abs(a - b);
// };

// const mult = (a, b) => {
//   return a * b;
// };

// const calculator = (num1, num2, operator) => {
//   return operator(num1, num2);
//   return add(5, 2);
// };

// console.log(calculator(5, 2, add));
// console.log(calculator(5, 2, sub));
// console.log(calculator(5, 2, mult));

// in the above example calculator is the Higher order function
// which accepts three arguements the third one being the callback
// here the calculator is called the Higher order function because it takes another
// function as arguement

// and add, sub, mult are called the callback function because they are passed as an arguement
//  to another function

//! ASYNCHORNUS IN JAVASCRIPT[[[[[[[[[[[[[[]]]]]]]]]]]]]]
// we will see

// HOISTING IN JAVASCRIPt
// Scope chain
// Lexical scoping in Javascript
// use Strict mode
// This keyword
// closures in JS
// what is Asynchronous Js programmming
// what is event loop

//! 1. HOISTING IN JAVASCRIPt

// we have a creation and execution phase

// Hoisting in JS is a mechanism where varaibles and functions
// declarationa are moved to top of their scope before the code is executed

// for ex

// console.log(myname); //undefined
// var myname;
// myname = 'kicha';

// how it will be in output during creation phase
// 1. var myname;
// 2. console.log(myname);
// 3. myname = 'kicha';

// IN ES2015 (a.k.a ES6), hoisting is avoided by using the let keyword
// insted of var (the other differece is that variables declared with let are local
// to the surrounding block, not the entire function)

//! 2. What is scope chain and lexical scoping in JS

// the scope chaine is used to resolve the value of variable names in js

// scope chain in js lexically defined, which means that we can
// see what the scope chain will be by looking at the code

// at the top we have global scope which is the window object in the browser

// lexical scoping means now the inner function can get access to their parent
// functions variables but the vice-veresa is not true

// For ex

// let a = 'HELLO GUYS. '; //global scope

// const first = () => {
//   let b = 'How r u?';

//   const second = () => {
//     let c = 'Hi, I am fine thank u';
//     console.log(a + b + c);
//   };
//   second();
//   console.log(a + b + c); // cant use C here
// };

// first();

//! closures in JS]]]]]]]]]]]]]]]]]]]]]]]]]

// A Clsure is a combination of a function bundled together (enclosed) with refernce to its
// surrounding state (a lexical environment )

// in other words, a closure gives you
// access to an outer functions  scope from an inner function

// IN Javascript closures are created every time a function is created at function creation time

// For Example 1

// const outerFun = (a) => {
//   let b = 10;
//   const innerFun = () => {
//     let sum = a + b;
//     console.log(`the sum of 2 nos ${sum}`);
//   };
//   innerFun();
// };
// outerFun(5);

// ex 2

// const outerFun = (a) => {
//         let b = 10;
//         const innerFun = () => {
//                 let sum = a+b;
//                 console.log(`the sum of the two numbers is ${sum}`);
//         }
//         return innerFun;
// }
// let checkClosure = outerFun(5);
// console.log(checkClosure());

// check for closur

// console.dir(checkClosure);

//! Use strict mode

// IO USE STRICKT ,ODE WE SHOULD USE VAR, LET, CONST

// let x = 'kicha';
// console.log(x);

// ....... BACK TO ADVANCE JAVASCRIPT]]]]]]]]]]]]]]]]]]]]]]]]]]]]]][[[[[[[[]]]]]]]]

//! Synchronus JS programmming

// const fun2 = () => {
//   console.log('Function 2 called');
// };

// const fun1 = () => {
//   console.log('Function 1 called');
//   fun2();
//   console.log('Function 1 called againe');
// };

// fun1();

//! Asynchronus JS programmming

// const fun2 = () => {
//   setTimeout(() => {
//     console.log('Function 2 called');
//   }, 2000);
// };

// const fun1 = () => {
//   console.log('Function 1 called');
//   fun2();
//   console.log('Function 1 called againe');
// };

// fun1();

//! FUNCTION CARRYNG(ASYNCHORNUS IN JAVASCRIPT)

// Currting is technique of evaluating fuction with multiple arguments into sequence
// of function with single argument

// function sum(num1) {
//   //   console.log(num1);
//   return function (num2) {
//     // console.log(num1, num2);
//     {
//       return function (num3) {
//         console.log(num1, num2, num3);
//       };
//     }
//   };
// }
// sum(5)(8)(3);

// OR EASY WAY................................

// const sum = (num1) => (num2) => (num3) => console.log(num1 + num2 + num3);
// sum(5)(8)(3);

//! 5)  CALLBACK HELL

// setTimeout(() => {
//   console.log('work is done 1');
//   setTimeout(() => {
//     console.log('work is done 2');
//     setTimeout(() => {
//       console.log('work is done 3');
//       setTimeout(() => {
//         console.log('work is done 4');
//         setTimeout(() => {
//           console.log('work is done 5');
//           setTimeout(() => {
//             console.log('work is done 6');
//           }, 1000);
//         }, 1000);
//       }, 1000);
//     }, 1000);
//   }, 1000);
// }, 1000);

//  CALLBACK HELL is very comlicated to over come this we use PROMISES

// we see in API CALL IN ANOTHER EILE

//!   bonus JSON [[[[[[[[[[[[[[]]]]]]]]]]]]]]

// JSON.stringify turns a javascript   object into JSON text and strores that
// JSON text in a string

// var my_object = { key_1: 'some text', key_2: true, key_3: 5 };

// var object_as_string = JSON.stringify(my_object);

// console.log(object_as_string);

// typeof object_as_string;
// // "string"

// JSON.parse turns a string of JSON text into a javascript Object

// var object_as_string_as_object = JSON.parse(object_as_string);

// typeof object_as_string_as_object;
