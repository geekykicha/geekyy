//!  PROMISES IN JS(JSON / fetch API)

// there will two condtions after using this method (promises in JSON- fetch api )
// either you will get the data(success) or not(fail)

// 2 cond => succsess or  => Fail
// fetch('https://restcountries.eu/rest/v2/name/nepal')

// milega      => sahi hai
// nahi milega => internet error or server error

// 90% we consume the not we create
// i.e

// fetch()
// fullfilled
// rejected

// GET https://icanhazdadjoke.com/

// const jokes = document.querySelector('#joke');
// const jokeBtn = document.querySelector('#jokeBtn');

// jokeBtn.addEventListener('click', generateJokes);
// generateJokes();

// const generateJokes = () => {
//   const setHeader = {
//     headers: {
//       accept: 'application/josn',
//     },
//   };

//   fetch('https://icanhazdadjoke.com')
//     .then((res) => res.json())
//     .then((data) => {
//       jokes.innerHTML = data.joke;
//     })
//     .catch((error) => {
//       console.log(error);
//     });
// };
// jokeBtn.addEventListener('click', generateJokes);


//! NOW BY USING ASSYNC AWAIT METHOD


const jokes = document.querySelector('#joke');
const jokeBtn = document.querySelector('#jokeBtn');


// if it is a normal function than

// async function generateJokes() {

// }

const generateJokes = async () => {

    try{
        const setHeader = {
            headers : {
                Accept: "Application/json"
            }
        }
        
        const res  = await  fetch('https://icanhazdadjoke.com', setHeader);
        const data = await res.json();
        jokes.innerHTML = data .joke;

    }catch(err){
        console.log(`the error is ${err}`);
    }
   
}

    jokeBtn.addEventListener('click', generateJokes);